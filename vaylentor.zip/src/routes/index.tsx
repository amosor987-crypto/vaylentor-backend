import { createFileRoute, Link } from "@tanstack/react-router";
import { Hero } from "@/components/vaylentor/Hero";
import { PackageCards } from "@/components/vaylentor/PackageCards";
import { Itinerary } from "@/components/vaylentor/Itinerary";

const title = "VAYLENTOR · סוכן הנסיעות ה‑AI שלכם";
const description =
  "VAYLENTOR מתכנן לכם חבילת חופשה שלמה — טיסות, מלון ומסלול יומי — בשלוש רמות מחיר, בעברית מלאה.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div dir="rtl" lang="he" className="min-h-screen bg-background font-sans">
      <header className="border-b border-border/70 bg-background/80 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
          <span className="font-display text-xl font-extrabold tracking-[0.22em] text-ink">
            VAYLENTOR
          </span>
          <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            <a href="#packages" className="transition-colors hover:text-ink">
              חבילות
            </a>
            <a href="#itinerary" className="transition-colors hover:text-ink">
              מסלולים
            </a>
            <a href="#" className="transition-colors hover:text-ink">
              איך זה עובד
            </a>
          </div>
          <Link
            to="/auth"
            className="rounded-full border border-ink/15 px-5 py-2 text-sm font-medium text-ink transition-colors hover:bg-secondary"
          >
            כניסה
          </Link>
        </nav>
      </header>

      <main>
        <Hero />
        <div id="packages">
          <PackageCards />
        </div>
        <div id="itinerary">
          <Itinerary />
        </div>
      </main>

      <footer className="border-t border-border py-10 text-center text-sm text-muted-foreground">
        © 2026 VAYLENTOR · כל הזכויות שמורות
      </footer>
    </div>
  );
}
