import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Mail, ShieldCheck, Sparkles } from "lucide-react";
import { DestinationReel } from "@/components/vaylentor/DestinationReel";

const title = "כניסה ל‑VAYLENTOR · סוכן הנסיעות ה‑AI שלכם";
const description =
  "התחברו ל‑VAYLENTOR כדי לשמור חבילות חופשה, לקבל מסלולים מותאמים אישית ולהזמין בלחיצה אחת.";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: AuthPage,
});

const perks = [
  { icon: Sparkles, label: "תכנון חופשה מלא בפחות משתי דקות" },
  { icon: ShieldCheck, label: "שמירת חבילות והזמנות במקום אחד" },
];

function AuthPage() {
  return (
    <div dir="rtl" lang="he" className="min-h-screen bg-background font-sans">
      <div className="grid min-h-screen lg:grid-cols-[1fr_0.9fr]">
        {/* Live video panel */}
        <div className="relative min-h-[38vh] overflow-hidden lg:min-h-screen">
          <DestinationReel className="absolute inset-0 size-full" showLabel={false} />
          <div
            aria-hidden
            className="absolute inset-0 bg-[image:var(--gradient-ink)] opacity-45 mix-blend-multiply"
          />


          <div className="relative flex h-full flex-col justify-between p-8 lg:p-12">
            <Link
              to="/"
              className="inline-flex w-fit items-center gap-2 rounded-full border border-sand/30 bg-ink/25 px-4 py-2 text-sm text-sand backdrop-blur transition-colors hover:bg-ink/40"
            >
              <ArrowLeft className="size-4 rotate-180" aria-hidden />
              חזרה לעמוד הבית
            </Link>

            <div className="max-w-lg">
              <p className="font-display text-sm font-bold tracking-[0.28em] text-brass-soft">
                VAYLENTOR
              </p>
              <h1 className="mt-4 text-4xl leading-[1.12] text-sand lg:text-5xl">
                הים כבר מחכה.
                <br />
                <span className="text-brass-gradient">נשאר רק להתחבר.</span>
              </h1>
              <ul className="mt-7 grid gap-3">
                {perks.map(({ icon: Icon, label }) => (
                  <li key={label} className="flex items-center gap-2.5 text-sm text-sand/85">
                    <Icon className="size-4 shrink-0 text-brass-soft" aria-hidden />
                    {label}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Form panel */}
        <div className="surface-paper flex items-center justify-center px-6 py-14 lg:px-12">
          <div className="w-full max-w-md">
            <span className="inline-flex items-center gap-2 rounded-full border border-brass/40 bg-card px-4 py-1.5 text-sm text-ink-soft shadow-soft">
              <Sparkles className="size-4 text-brass" aria-hidden />
              כניסה לחשבון
            </span>

            <h2 className="mt-6 text-3xl text-ink">ברוכים השבים</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              התחברו כדי להמשיך את תכנון החופשה מהמקום שבו עצרתם.
            </p>

            <form
              className="mt-8 grid gap-4"
              onSubmit={(e) => {
                e.preventDefault();
              }}
            >
              <div className="grid gap-2">
                <label htmlFor="email" className="text-sm font-medium text-ink-soft">
                  אימייל
                </label>
                <input
                  id="email"
                  type="email"
                  dir="ltr"
                  placeholder="you@example.com"
                  className="h-12 rounded-2xl border border-border bg-card px-4 text-ink outline-none transition-shadow placeholder:text-muted-foreground/60 focus:border-brass/60 focus:shadow-soft"
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="password" className="text-sm font-medium text-ink-soft">
                  סיסמה
                </label>
                <input
                  id="password"
                  type="password"
                  dir="ltr"
                  placeholder="••••••••"
                  className="h-12 rounded-2xl border border-border bg-card px-4 text-ink outline-none transition-shadow placeholder:text-muted-foreground/60 focus:border-brass/60 focus:shadow-soft"
                />
              </div>

              <button
                type="submit"
                className="mt-2 inline-flex h-13 items-center justify-center gap-2 rounded-2xl bg-[image:var(--gradient-ink)] px-7 py-4 text-base font-semibold text-primary-foreground shadow-card transition-transform duration-300 hover:scale-[1.02]"
              >
                כניסה
                <ArrowLeft className="size-5" aria-hidden />
              </button>

              <div className="my-1 flex items-center gap-3 text-xs text-muted-foreground">
                <span className="hairline-brass h-px flex-1" />
                או
                <span className="hairline-brass h-px flex-1" />
              </div>

              <button
                type="button"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl border border-border bg-card text-sm font-medium text-ink transition-colors hover:border-brass/50"
              >
                <Mail className="size-4 text-brass" aria-hidden />
                כניסה עם קישור חד‑פעמי במייל
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-muted-foreground">
              עוד אין לכם חשבון?{" "}
              <button type="button" className="font-medium text-ink underline-offset-4 hover:underline">
                הרשמה חינם
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
