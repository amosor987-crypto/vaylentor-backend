const days = [
  {
    day: "יום 1",
    title: "נחיתה ונאפולי הישנה",
    time: "10:20 נחיתה",
    items: ["איסוף פרטי משדה התעופה", "צ׳ק‑אין במלון הבוטיק", "ארוחת ערב בפיצריה היסטורית"],
  },
  {
    day: "יום 2",
    title: "פומפיי והוזוב",
    time: "יום מלא",
    items: ["סיור מודרך באתר פומפיי", "עלייה קלה לוזוב", "טעימות יין מקומי בכרם"],
  },
  {
    day: "יום 3",
    title: "שיט לאמלפי",
    time: "בוקר עד שקיעה",
    items: ["שיט פרטי לאורך החוף", "עצירת רחצה במפרץ שקט", "ערב חופשי בכיכר העיר"],
  },
  {
    day: "יום 4",
    title: "קפרי ומנוחה",
    time: "יום רגוע",
    items: ["מעבורת בוקר לקפרי", "המערה הכחולה", "ספא וערב מוקדם במלון"],
  },
];

export function Itinerary() {
  return (
    <section className="surface-ink">
      <div className="mx-auto max-w-4xl px-6 py-20">
        <header className="text-center">
          <p className="text-sm font-semibold tracking-[0.18em] text-brass">מסלול יומי</p>
          <h2 className="mt-3 text-4xl text-primary-foreground sm:text-5xl">
            שבעה ימים, מתוכננים בקצב שלכם
          </h2>
        </header>

        <ol className="relative mt-14 space-y-8 border-e border-[oklch(1_0_0_/_0.16)] pe-8">
          {days.map((d) => (
            <li key={d.day} className="relative">
              <span
                aria-hidden
                className="absolute -end-[2.28rem] top-1.5 size-3.5 rounded-full bg-[image:var(--gradient-brass)] ring-4 ring-[oklch(0.26_0.045_200)]"
              />
              <div className="rounded-2xl border border-[oklch(1_0_0_/_0.1)] bg-[oklch(1_0_0_/_0.05)] p-6">
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <span className="text-sm font-semibold text-brass">{d.day}</span>
                  <h3 className="text-xl text-primary-foreground">{d.title}</h3>
                  <span className="text-xs text-primary-foreground/60">{d.time}</span>
                </div>
                <ul className="mt-4 space-y-2">
                  {d.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2.5 text-sm text-primary-foreground/80"
                    >
                      <span
                        aria-hidden
                        className="mt-2 size-1.5 shrink-0 rounded-full bg-brass/70"
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
