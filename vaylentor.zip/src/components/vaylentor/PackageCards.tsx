import { Check } from "lucide-react";

type Pkg = {
  emoji: string;
  tier: string;
  subtitle: string;
  price: string;
  per: string;
  highlights: string[];
  why: string;
  featured?: boolean;
};

const packages: Pkg[] = [
  {
    emoji: "💰",
    tier: "חכם",
    subtitle: "הכי משתלם",
    price: "₪4,290",
    per: "לאדם · 6 לילות",
    highlights: [
      "טיסה ישירה מת״א עם כבודה",
      "מלון 3★ במרכז, דירוג 8.2",
      "העברות משדה התעופה כלולות",
    ],
    why: "בחרנו את זה כי הפער במחיר מול המסלול הבינוני הוא 38%, והמלון עדיין במרחק הליכה מהמרכז ההיסטורי.",
  },
  {
    emoji: "⭐",
    tier: "מומלץ",
    subtitle: "האיזון הנכון",
    price: "₪6,850",
    per: "לאדם · 7 לילות",
    highlights: [
      "טיסת בוקר ישירה + חזרה בערב",
      "מלון בוטיק 4★ עם ארוחת בוקר",
      "סיור קולינרי וכרטיסים מראש",
      "ביטול חינם עד 14 יום",
    ],
    why: "זו החבילה שרוב המשפחות בוחרות: המלון הכי מדורג בטווח, וההפרש מול הפרימיום מורגש רק בשירותי הספא.",
    featured: true,
  },
  {
    emoji: "👑",
    tier: "יוקרה",
    subtitle: "בלי פשרות",
    price: "₪12,400",
    per: "לאדם · 7 לילות",
    highlights: [
      "מחלקת עסקים הלוך ושוב",
      "סוויטה 5★ עם נוף לים",
      "רכב פרטי עם נהג לכל השהות",
      "קונסיירז' אישי בוואטסאפ",
    ],
    why: "אם אתם נוסעים לציון תאריך מיוחד — המלון הזה הוא היחיד באזור עם גישה פרטית לחוף ודירוג 9.4.",
  },
];

export function PackageCards() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold tracking-[0.18em] text-brass">שלוש אפשרויות</p>
        <h2 className="mt-3 text-4xl text-ink sm:text-5xl">אותה חופשה, שלוש רמות</h2>
        <p className="mt-4 text-muted-foreground">
          כל חבילה כוללת טיסות, לינה ומסלול — ומסבירה בדיוק למה נבחרה.
        </p>
      </header>

      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {packages.map((p) => (
          <article
            key={p.tier}
            className={[
              "card-lift relative flex flex-col rounded-3xl border p-8",
              p.featured
                ? "border-brass/50 surface-ink shadow-glow-brass lg:-mt-6 lg:mb-6"
                : "border-border bg-card shadow-soft",
            ].join(" ")}
          >
            {p.featured && (
              <span className="absolute -top-3.5 right-8 rounded-full bg-[image:var(--gradient-brass)] px-4 py-1 text-xs font-bold text-accent-foreground shadow-card">
                הבחירה של VAYLENTOR
              </span>
            )}

            <div className="flex items-baseline justify-between">
              <h3
                className={`text-2xl ${p.featured ? "text-primary-foreground" : "text-ink"}`}
              >
                <span className="ms-2" aria-hidden>
                  {p.emoji}
                </span>
                {p.tier}
              </h3>
              <span
                className={`text-sm ${p.featured ? "text-brass-soft" : "text-muted-foreground"}`}
              >
                {p.subtitle}
              </span>
            </div>

            <div className="mt-7">
              <div
                className={`font-display text-4xl font-extrabold ${
                  p.featured ? "text-brass-soft" : "text-ink"
                }`}
              >
                {p.price}
              </div>
              <div
                className={`mt-1 text-sm ${
                  p.featured ? "text-primary-foreground/70" : "text-muted-foreground"
                }`}
              >
                {p.per}
              </div>
            </div>

            <ul className="mt-7 space-y-3">
              {p.highlights.map((h) => (
                <li
                  key={h}
                  className={`flex items-start gap-2.5 text-sm leading-relaxed ${
                    p.featured ? "text-primary-foreground/90" : "text-ink-soft"
                  }`}
                >
                  <Check
                    className={`mt-0.5 size-4 shrink-0 ${p.featured ? "text-brass" : "text-success"}`}
                    aria-hidden
                  />
                  {h}
                </li>
              ))}
            </ul>

            <div
              className={`mt-7 rounded-2xl p-4 text-sm leading-relaxed ${
                p.featured
                  ? "bg-[oklch(1_0_0_/_0.08)] text-primary-foreground/85"
                  : "bg-secondary/70 text-muted-foreground"
              }`}
            >
              <span className="block text-xs font-semibold tracking-wide text-brass">
                למה בחרנו בזה
              </span>
              <span className="mt-1.5 block">{p.why}</span>
            </div>

            <button
              type="button"
              className={`mt-8 h-12 w-full rounded-2xl text-base font-semibold transition-transform duration-300 hover:scale-[1.02] ${
                p.featured
                  ? "bg-[image:var(--gradient-brass)] text-accent-foreground shadow-card"
                  : "border border-ink/15 bg-transparent text-ink hover:bg-secondary"
              }`}
            >
              הזמנת החבילה
            </button>
          </article>
        ))}
      </div>
    </section>
  );
}
