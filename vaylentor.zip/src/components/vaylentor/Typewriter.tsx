import { useEffect, useState } from "react";

export function Typewriter({
  phrases,
  className = "",
  typeMs = 65,
  holdMs = 1900,
}: {
  phrases: string[];
  className?: string;
  typeMs?: number;
  holdMs?: number;
}) {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const full = phrases[index] ?? "";

    if (!deleting && text === full) {
      const id = window.setTimeout(() => setDeleting(true), holdMs);
      return () => window.clearTimeout(id);
    }

    if (deleting && text === "") {
      setDeleting(false);
      setIndex((i) => (i + 1) % phrases.length);
      return;
    }

    const id = window.setTimeout(
      () => setText(full.slice(0, text.length + (deleting ? -1 : 1))),
      deleting ? typeMs / 2 : typeMs,
    );
    return () => window.clearTimeout(id);
  }, [text, deleting, index, phrases, typeMs, holdMs]);

  return (
    <span className={className}>
      <span className="text-brass-gradient">{text}</span>
      <span
        aria-hidden
        className="ms-0.5 inline-block h-[0.85em] w-[3px] translate-y-[0.08em] rounded-full bg-brass align-middle animate-pulse"
      />
    </span>
  );
}
