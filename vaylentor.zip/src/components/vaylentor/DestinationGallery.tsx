import { useRef } from "react";
import { ArrowLeft } from "lucide-react";
import coast from "@/assets/auth-loop.mp4.asset.json";
import thailand from "@/assets/loop-thailand.mp4.asset.json";
import paris from "@/assets/loop-paris.mp4.asset.json";
import tokyo from "@/assets/loop-tokyo.mp4.asset.json";
import poster from "@/assets/hero-coast.jpg";

const cards = [
  { url: coast.url, name: "אמלפי", country: "איטליה", price: "מ‑₪3,940", tag: "ים תיכוני" },
  { url: thailand.url, name: "קראבי", country: "תאילנד", price: "מ‑₪5,120", tag: "טרופי" },
  { url: paris.url, name: "פריז", country: "צרפת", price: "מ‑₪2,780", tag: "עירוני" },
  { url: tokyo.url, name: "טוקיו", country: "יפן", price: "מ‑₪6,390", tag: "רחוק ומיוחד" },
];

function GalleryCard({ card }: { card: (typeof cards)[number] }) {
  const ref = useRef<HTMLVideoElement>(null);

  return (
    <article
      className="group relative h-[340px] overflow-hidden rounded-[1.75rem] border border-brass/20 shadow-card card-lift"
      onMouseEnter={() => void ref.current?.play().catch(() => {})}
      onMouseLeave={() => ref.current?.pause()}
    >
      <video
        ref={ref}
        src={card.url}
        poster={poster}
        muted
        loop
        playsInline
        preload="metadata"
        aria-hidden
        className="absolute inset-0 size-full scale-105 object-cover transition-transform duration-[1200ms] ease-[var(--ease-soft)] group-hover:scale-100"
      />
      <div
        aria-hidden
        className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/25 to-transparent"
      />
      <div className="absolute inset-x-0 bottom-0 p-6">
        <span className="rounded-full bg-[oklch(1_0_0_/_0.16)] px-3 py-1 text-xs text-primary-foreground backdrop-blur">
          {card.tag}
        </span>
        <h3 className="mt-3 font-display text-2xl text-primary-foreground">{card.name}</h3>
        <p className="text-sm text-primary-foreground/70">{card.country}</p>
        <div className="mt-4 flex items-center justify-between opacity-0 transition-opacity duration-500 group-hover:opacity-100">
          <span className="text-sm font-semibold text-brass">{card.price}</span>
          <ArrowLeft className="size-4 text-brass" aria-hidden />
        </div>
      </div>
    </article>
  );
}

export function DestinationGallery() {
  return (
    <section className="surface-paper">
      <div className="mx-auto max-w-7xl px-6 py-20">
        <header className="max-w-2xl">
          <p className="text-sm font-semibold tracking-[0.18em] text-brass">יעדים חיים</p>
          <h2 className="mt-3 text-4xl text-ink sm:text-5xl">העבירו עכבר — וראו את המקום נושם</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            כל יעד עם סרטון קצר מהשטח, מחיר התחלתי מעודכן וזמינות אמיתית.
          </p>
        </header>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <GalleryCard key={c.name} card={c} />
          ))}
        </div>
      </div>
    </section>
  );
}
