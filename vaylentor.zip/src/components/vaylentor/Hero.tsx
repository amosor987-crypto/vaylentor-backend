import { ArrowLeft, Plane, ShieldCheck, Sparkles } from "lucide-react";
import { DestinationReel } from "@/components/vaylentor/DestinationReel";

const suggestions = [
  "סופ״ש רומנטי ברומא",
  "10 ימים ביפן עם ילדים",
  "חופשת סקי באלפים",
  "אי יווני שקט בספטמבר",
];

const trust = [
  { icon: ShieldCheck, label: "תשלום מאובטח וסליקה ישראלית" },
  { icon: Plane, label: "מחירים בזמן אמת מ‑450 חברות תעופה" },
  { icon: Sparkles, label: "תכנון מלא בפחות משתי דקות" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden surface-paper">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 left-[-10%] h-[520px] w-[520px] rounded-full bg-brass-soft/40 blur-3xl"
      />
      <div className="mx-auto grid max-w-7xl gap-14 px-6 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:py-24">
        <div className="relative">
          <span className="inline-flex items-center gap-2 rounded-full border border-brass/40 bg-card px-4 py-1.5 text-sm font-medium text-ink-soft shadow-soft">
            <Sparkles className="size-4 text-brass" aria-hidden />
            סוכן הנסיעות ה‑AI הראשון בעברית
          </span>

          <h1 className="mt-7 text-5xl leading-[1.08] text-ink sm:text-6xl lg:text-7xl">
            החופשה הבאה שלכם,
            <br />
            <span className="text-brass-gradient">מתוכננת עד הפרט האחרון.</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            ספרו לנו לאן, מתי ועם מי — ו‑VAYLENTOR יבנה חבילה שלמה: טיסות, מלון ומסלול
            יומי. שלוש רמות מחיר, הסבר על כל בחירה, והזמנה בלחיצה אחת.
          </p>

          <form
            className="mt-9 rounded-3xl border border-border bg-card p-2.5 shadow-elevated"
            onSubmit={(e) => e.preventDefault()}
          >
            <div className="flex flex-col gap-2.5 sm:flex-row-reverse sm:items-center">
              <label htmlFor="ai-prompt" className="sr-only">
                לאן בא לכם לטוס?
              </label>
              <input
                id="ai-prompt"
                dir="rtl"
                placeholder="לאן בא לכם לטוס?"
                className="h-14 flex-1 rounded-2xl bg-transparent px-5 text-lg text-ink outline-none placeholder:text-muted-foreground/70"
              />
              <button
                type="submit"
                className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-[image:var(--gradient-ink)] px-7 text-base font-semibold text-primary-foreground shadow-card transition-transform duration-300 hover:scale-[1.02]"
              >
                תכננו לי חופשה
                <ArrowLeft className="size-5" aria-hidden />
              </button>
            </div>
          </form>

          <div className="mt-5 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button
                key={s}
                type="button"
                className="rounded-full border border-border bg-secondary/60 px-4 py-2 text-sm text-ink-soft transition-colors hover:border-brass/50 hover:bg-card"
              >
                {s}
              </button>
            ))}
          </div>

          <ul className="mt-10 grid gap-4 sm:grid-cols-3">
            {trust.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                <Icon className="mt-0.5 size-4 shrink-0 text-sea" aria-hidden />
                {label}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <DestinationReel className="h-[420px] w-full rounded-[2.5rem] border border-brass/25 shadow-elevated lg:h-[620px]" />
        </div>
      </div>
      <div aria-hidden className="hairline-brass h-px w-full" />
    </section>
  );
}
