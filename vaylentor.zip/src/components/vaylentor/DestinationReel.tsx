import { useEffect, useState } from "react";
import coast from "@/assets/auth-loop.mp4.asset.json";
import thailand from "@/assets/loop-thailand.mp4.asset.json";
import paris from "@/assets/loop-paris.mp4.asset.json";
import tokyo from "@/assets/loop-tokyo.mp4.asset.json";
import posterImage from "@/assets/hero-coast.jpg";

export const destinations = [
  { url: coast.url, name: "אמלפי, איטליה", tag: "חופים ים תיכוניים" },
  { url: thailand.url, name: "קראבי, תאילנד", tag: "איים טרופיים" },
  { url: paris.url, name: "פריז, צרפת", tag: "ערים קלאסיות" },
  { url: tokyo.url, name: "טוקיו, יפן", tag: "אורות עיר" },
];

const INTERVAL = 6500;

export function DestinationReel({
  className = "",
  showLabel = true,
}: {
  className?: string;
  showLabel?: boolean;
}) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = window.setInterval(
      () => setActive((i) => (i + 1) % destinations.length),
      INTERVAL,
    );
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {destinations.map((d, i) => (
        <video
          key={d.url}
          src={d.url}
          poster={posterImage}
          autoPlay
          muted
          loop
          playsInline
          preload={i === 0 ? "auto" : "metadata"}
          aria-hidden
          className={`absolute inset-0 size-full object-cover transition-opacity duration-[1400ms] ease-[var(--ease-soft)] ${
            i === active ? "opacity-100" : "opacity-0"
          }`}
        />
      ))}

      <div
        aria-hidden
        className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-ink/75 via-ink/20 to-transparent"
      />

      {showLabel && (
        <div className="absolute bottom-5 right-5 left-5 flex justify-end gap-1.5">
          {destinations.map((d, i) => (
            <button
              key={d.url}
              type="button"
              aria-label={d.name}
              onClick={() => setActive(i)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === active ? "w-7 bg-brass" : "w-3 bg-sand/45 hover:bg-sand/70"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
