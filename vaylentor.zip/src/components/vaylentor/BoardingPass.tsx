import { Bed, Plane, Star } from "lucide-react";

const tickets = [
  {
    kind: "טיסה",
    icon: Plane,
    from: "TLV",
    to: "FCO",
    title: "אל על · LY381",
    lines: [
      ["המראה", "06:45"],
      ["נחיתה", "09:30"],
      ["שער", "B14"],
      ["מושב", "12A"],
    ],
    code: "VYL‑8842",
  },
  {
    kind: "מלון",
    icon: Bed,
    from: "צ׳ק‑אין",
    to: "צ׳ק‑אאוט",
    title: "Palazzo Marino · 4★",
    lines: [
      ["כניסה", "14:00"],
      ["יציאה", "11:00"],
      ["חדר", "Deluxe"],
      ["ארוחות", "בוקר"],
    ],
    code: "VYL‑5510",
  },
  {
    kind: "חוויה",
    icon: Star,
    from: "סיור",
    to: "קולינרי",
    title: "Trastevere Food Walk",
    lines: [
      ["מפגש", "18:30"],
      ["משך", "3 שעות",],
      ["שפה", "אנגלית"],
      ["דירוג", "9.6"],
    ],
    code: "VYL‑2077",
  },
];

export function BoardingPass() {
  return (
    <section className="surface-paper">
      <div className="mx-auto max-w-7xl px-6 py-20">
        <header className="max-w-2xl">
          <p className="text-sm font-semibold tracking-[0.18em] text-brass">התיק שלכם</p>
          <h2 className="mt-3 text-4xl text-ink sm:text-5xl">כל הזמנה כמו כרטיס עלייה למטוס</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            טיסות, מלונות וחוויות מגיעים בפורמט אחיד, ברור, מוכן להצגה בשדה או בקבלה.
          </p>
        </header>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {tickets.map(({ icon: Icon, ...t }) => (
            <article
              key={t.code}
              className="relative overflow-hidden rounded-[1.5rem] border border-border bg-card shadow-card card-lift"
            >
              <div className="flex items-center justify-between bg-[image:var(--gradient-ink)] px-6 py-4 text-primary-foreground">
                <span className="flex items-center gap-2 text-sm font-semibold">
                  <Icon className="size-4 text-brass" aria-hidden />
                  {t.kind}
                </span>
                <span className="font-sans text-xs tracking-[0.2em] text-primary-foreground/60">
                  VAYLENTOR
                </span>
              </div>

              <div className="px-6 pt-6">
                <div className="flex items-center justify-between gap-3">
                  <span className="font-display text-2xl text-ink">{t.from}</span>
                  <span aria-hidden className="hairline-brass h-px flex-1" />
                  <span className="font-display text-2xl text-ink">{t.to}</span>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{t.title}</p>
              </div>

              <div className="relative mt-6">
                <span
                  aria-hidden
                  className="absolute -end-3 top-1/2 size-6 -translate-y-1/2 rounded-full bg-background"
                />
                <span
                  aria-hidden
                  className="absolute -start-3 top-1/2 size-6 -translate-y-1/2 rounded-full bg-background"
                />
                <div
                  aria-hidden
                  className="mx-6 border-t border-dashed border-border"
                />
              </div>

              <dl className="grid grid-cols-2 gap-4 px-6 py-6">
                {t.lines.map(([k, v]) => (
                  <div key={k}>
                    <dt className="text-xs text-muted-foreground">{k}</dt>
                    <dd className="mt-0.5 text-base font-medium text-ink">{v}</dd>
                  </div>
                ))}
              </dl>

              <div className="flex items-center justify-between gap-4 border-t border-border px-6 py-4">
                <span className="font-sans text-xs tracking-[0.18em] text-muted-foreground">
                  {t.code}
                </span>
                <span aria-hidden className="flex h-8 items-end gap-[2px]">
                  {Array.from({ length: 26 }).map((_, i) => (
                    <span
                      key={i}
                      className="w-[2px] rounded-sm bg-ink/70"
                      style={{ height: `${40 + ((i * 37) % 60)}%` }}
                    />
                  ))}
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
