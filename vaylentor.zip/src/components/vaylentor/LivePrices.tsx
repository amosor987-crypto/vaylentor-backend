import { useEffect, useState } from "react";
import { TrendingDown, TrendingUp } from "lucide-react";

const routes = [
  { code: "TLV → FCO", city: "רומא", base: 780 },
  { code: "TLV → BKK", city: "בנגקוק", base: 2140 },
  { code: "TLV → CDG", city: "פריז", base: 890 },
  { code: "TLV → NRT", city: "טוקיו", base: 3120 },
  { code: "TLV → ATH", city: "אתונה", base: 420 },
  { code: "TLV → BCN", city: "ברצלונה", base: 640 },
];

type Row = { delta: number; price: number };

export function LivePrices() {
  const [rows, setRows] = useState<Row[]>(() =>
    routes.map((r) => ({ price: r.base, delta: 0 })),
  );

  useEffect(() => {
    const id = window.setInterval(() => {
      setRows((prev) =>
        routes.map((route, i) => {
          const row = prev[i]!;
          const drift = Math.round((Math.random() - 0.5) * route.base * 0.04);
          const next = Math.max(Math.round(route.base * 0.8), row.price + drift);
          return { price: next, delta: next - row.price };
        }),
      );
    }, 2200);
    return () => window.clearInterval(id);
  }, []);

  return (
    <section className="surface-ink">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-sm font-semibold tracking-[0.18em] text-brass">
              <span
                aria-hidden
                className="rounded-full border border-brass/40 px-2 py-0.5 text-xs"
              >
                לדוגמה
              </span>
              טווחי מחירים
            </p>
            <h2 className="mt-3 text-4xl text-primary-foreground">הבורסה של הטיסות שלכם</h2>
          </div>
          <p className="max-w-sm text-sm text-primary-foreground/60">
            טווחי מחירים לדוגמה למסלולים פופולריים — הערכה כללית שתשתנה לפי תאריכים,
            ביקוש וזמינות.
          </p>
        </div>

        <p className="mt-3 text-xs text-primary-foreground/40">
          לדוגמה בלבד — לא מחיר בזמן אמת. המספרים המוצגים הם הערכות אילוסטרטיביות ולא נתונים
          חיים מספקים.
        </p>

        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {routes.map((r, i) => {
            const row = rows[i]!;
            const down = row.delta < 0;
            return (
              <div
                key={r.code}
                className="flex items-center justify-between rounded-2xl border border-[oklch(1_0_0_/_0.1)] bg-[oklch(1_0_0_/_0.05)] px-5 py-4"
              >
                <div>
                  <p className="font-sans text-xs tracking-[0.14em] text-primary-foreground/55">
                    {r.code}
                  </p>
                  <p className="mt-1 text-lg text-primary-foreground">{r.city}</p>
                </div>
                <div className="text-end">
                  <p className="font-display text-2xl tabular-nums text-brass transition-all duration-500">
                    ₪{row.price.toLocaleString("he-IL")}
                  </p>
                  <p
                    className={`mt-1 flex items-center justify-end gap-1 text-xs tabular-nums ${
                      down ? "text-success" : "text-clay"
                    }`}
                  >
                    {down ? (
                      <TrendingDown className="size-3.5" aria-hidden />
                    ) : (
                      <TrendingUp className="size-3.5" aria-hidden />
                    )}
                    {row.delta === 0 ? "יציב" : `${down ? "" : "+"}${row.delta}`}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
